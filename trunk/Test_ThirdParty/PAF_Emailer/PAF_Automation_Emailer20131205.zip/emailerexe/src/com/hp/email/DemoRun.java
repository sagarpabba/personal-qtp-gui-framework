package com.hp.email;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class DemoRun {
	
	public static void main(String[] args) {
		
		
		String inputfile="c:\\temp\\result_template.htm";
		Document doc = Jsoup.parse(inputfile, "UTF-8");
		System.out.println(doc.toString());
		
		// tested parameter is:
	}

}
